﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MedicalCentre
{
    public partial class DoctorHome : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user=root;database=mcuov;port=3306;password=");
        public DoctorHome()
        {
            InitializeComponent();
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //for update part for studnet(SQL)

            string insertQuery = "INSERT INTO mcuov.std_prescription(regNum,date,findings,medicine) VALUES('" + txtReg.Text + "','" + date.Text + "','" + treatment.Text + "','" + medecine.Text + "') ";
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(insertQuery, conn);

            try
            {
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Data Inserted!");
                }
                else
                {
                    MessageBox.Show("Data not Inserted");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

           

            conn.Close();


            

            





            //clear records
            lblName.Text = "";
            lblAge.Text = "";
            lblAllergy.Text = "";
            lblDep.Text = "";
            lblDesig.Text = "";
            lblFac.Text = "";
            lblServ.Text = "";
            lblSex.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            lg.Show();
            this.Hide();
        }

        private void DoctorHome_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM stdreg WHERE regNum='" + txtReg.Text + "'";

            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            using(MySqlDataReader dr=cmd.ExecuteReader())
            {
                if(dr.Read())
                {
                    lblName.Text = dr["name"].ToString();
                    lblSex.Text = dr["sex"].ToString();
                    lblAge.Text = dr["age"].ToString();
                    lblAllergy.Text = dr["allergic"].ToString();
                    lblDep.Text = dr["dept"].ToString();
                    lblDesig.Text = dr["designation"].ToString();
                    lblFac.Text = dr["faculty"].ToString();
                    lblServ.Text = dr["regNum"].ToString();
                }
            }

            conn.Close();

            string sql2 = "SELECT * FROM stfreg WHERE stfId='" + txtReg.Text + "' ";

            MySqlCommand cmd2 = new MySqlCommand(sql2, conn);
            conn.Open();
            using(MySqlDataReader dr2=cmd2.ExecuteReader())
            {
                if(dr2.Read())
                {
                    lblName.Text=dr2["name"].ToString();
                    lblSex.Text = dr2["sex"].ToString();
                    lblAge.Text = dr2["age"].ToString();
                    lblAllergy.Text = dr2["allergic"].ToString() ;
                    lblDep.Text = dr2["dept"].ToString();
                    lblDesig.Text = dr2["designation"].ToString();
                    lblFac.Text = dr2["faculty"].ToString();
                    lblServ.Text = dr2["stfId"].ToString();
                }
            }
            conn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MedicalHistory med = new MedicalHistory();
            this.Hide();
            med.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Medical md = new Medical();
            this.Hide();
            md.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //for update part for staff(SQL)
            string insertQuery2 = "INSERT INTO mcuov.stf_prescription(stfId,date,findings,medicine) VALUES('" + txtReg.Text + "','" + date.Text + "','" + treatment.Text + "','" + medecine.Text + "') ";
            conn.Open();
            MySqlCommand cmd2 = new MySqlCommand(insertQuery2, conn);

            try
            {
                if (cmd2.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Data Inserted!");
                }
                else
                {
                    MessageBox.Show("Data not Inserted");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            conn.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Records rg = new Records();
            rg.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            StudentAll st = new StudentAll();
            st.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            StaffAll st = new StaffAll();
            st.Show();
        }
    }
}
