﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MedicalCentre
{
    public partial class MedicalHistory : Form
    {

        public MedicalHistory()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Hide();
            lg.Show();
        }

        private void MedicalHistory_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ConnectionString = "server=localhost;user=root;database=mcuov;port=3306;password=";
            //for students
            using(MySqlConnection conn = new MySqlConnection(ConnectionString))
            {
                //Data Set 1
                MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT regNum,name,sex,age,bloodgroup,allergic,allergicHx,pastMedHis,pastSurgery,vaccination FROM mcuov.stdreg WHERE regNum='" + txtRegNum.Text + "' ", conn);
                DataTable tbl = new DataTable();
                sqlDa.Fill(tbl);

                dataShow.DataSource = tbl;

                //Data Set2

                MySqlDataAdapter sqlData = new MySqlDataAdapter("SELECT regNum,date,findings,medicine FROM mcuov.std_prescription WHERE regNum='" + txtRegNum.Text + "' ", conn);
                DataTable tbl2 = new DataTable();
                sqlData.Fill(tbl2);

                dataShow2.DataSource= tbl2;
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DoctorHome dc = new DoctorHome();
            this.Hide();
            dc.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //for staff
            string ConnectionString = "server=localhost;user=root;database=mcuov;port=3306;password=";
            using (MySqlConnection conn2=new MySqlConnection(ConnectionString))
             {
                 //Data set 1
                 MySqlDataAdapter sqldata1 = new MySqlDataAdapter("SELECT stfId,name,sex,age,bloodgroup,allergic,allergicHx,pastMedHis,pastSurgery,vaccination FROM mcuov.stfreg WHERE stfId='" + txtStaffId.Text + "' ", conn2);
                 DataTable tb3=new DataTable();
                 sqldata1.Fill(tb3);

                 dataShow.DataSource= tb3;

                 //Data Set 2
                 MySqlDataAdapter sqlData2 = new MySqlDataAdapter("SELECT * FROM stf_prescription WHERE stfId='" + txtStaffId.Text + "' ", conn2);
                 DataTable tbl4 = new DataTable();
                 sqlData2.Fill(tbl4);

                 dataShow2.DataSource= tbl4;
             }
        }
    }
}
