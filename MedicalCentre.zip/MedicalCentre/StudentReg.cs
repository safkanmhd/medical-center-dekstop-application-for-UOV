﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MedicalCentre
{
    public partial class StudentReg : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user=root;database=mcuov;port=3306;password=");
        public StudentReg()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login lg=new Login();
            lg.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReceptionistSelection res=new ReceptionistSelection();
            res.Show();
            this.Hide();
        }

        private void StudentReg_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string insertQuery = "INSERT INTO mcuov.stdreg(regNum,name,sex,age,bloodgroup,designation,allergic,dept,faculty,resAddress,perAddress,allergicHx,pastMedHis,pastSurgery,vaccination) VALUES('" + stdReg.Text + "','" + stdName.Text + "','" + stdSex.Text + "','" + stdAge.Text + "','" + stdBld.Text + "','" + stdDes.Text + "','" + stdAller.Text + "','" + stdDept.Text + "','" + stdFac.Text + "','" + stdResAd.Text + "','" + stdPerAd.Text + "','" + stdAllergyHx.Text + "','" + stdPastMed.Text + "','" + stdSurg.Text + "','" + stdVacc.Text + "')";
            conn.Open();
            MySqlCommand cmd=new MySqlCommand(insertQuery, conn);

            try
            {
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Registration Success!");
                }
                else
                {
                    MessageBox.Show("Registartion Failed");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            conn.Close();

            stdAge.Text = "";
            stdAller.Text = "";
            stdAllergyHx.Text = "";
            stdBld.Text = "";
            stdDept.Text = "";
            stdDes.Text = "";
            stdFac.Text = "";
            stdName.Text = "";
            stdPastMed.Text = "";
            stdPerAd.Text = "";
            stdReg.Text = "";
            stdResAd.Text = "";
            stdSex.Text = "";
            stdSurg.Text = "";
            stdVacc.Text = "";
        }
    }
}
