﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MedicalCentre
{
    public partial class Medical : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user=root;database=mcuov;port=3306;password=");
        public Medical()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DoctorHome dc=new DoctorHome();
            this.Hide();
            dc.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Hide();
            lg.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM stdreg WHERE regNum='" + txtReg.Text + "'";
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            using (MySqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    txtName.Text = dr["name"].ToString();

                }
            }

            conn.Close();

            string sql2 = "SELECT * FROM mcuov.medical_certificate WHERE RegNum='" + txtReg.Text + "' ";
            conn.Open();
            MySqlCommand cmd2=new MySqlCommand(sql2, conn);
            using(MySqlDataReader dr2= cmd2.ExecuteReader())
            {
                if(dr2.Read())
                {
                    txtCc.Text = dr2["Course_Code"].ToString();
                    txtli.Text = dr2["Lecturer_Incharge"].ToString();
                    txtMd.Text = dr2["Subject_Name"].ToString();
                    txtMdI.Text = dr2["Medical_Issue"].ToString();
                    
                }
            }
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string insertQuery = "UPDATE mcuov.medical_certificate SET Remarks='"+txtRemarks.Text+"' WHERE RegNum='"+txtReg.Text+"' ";
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(insertQuery, conn);

            try
            {
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Data Inserted!");
                }
                else
                {
                    MessageBox.Show("Data not Inserted");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            conn.Close();

            txtCc.Text = "";
            txtli.Text = "";
            txtMd.Text = "";
            txtMdI.Text = "";
            txtName.Text = "";
            txtReg.Text = "";
            txtRemarks.Text = "";
        }

        private void Medical_Load(object sender, EventArgs e)
        {

        }
    }
}
