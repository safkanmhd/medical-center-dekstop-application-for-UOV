﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MedicalCentre
{
    public partial class MedicalCertificate : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user=root;database=mcuov;port=3306;password=");
        public MedicalCertificate()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM stdreg WHERE regNum='" + txtRegNum.Text + "'";
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            using (MySqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    stdName.Text = dr["name"].ToString();
                    stdDept.Text = dr["dept"].ToString();
                    stdFac.Text = dr["faculty"].ToString();
                   
                }
            }

            conn.Close();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
           
        }

        
        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void MedicalCertificate_Load(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Hide();
            lg.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReceptionistSelection rc = new ReceptionistSelection();
            this.Hide();
            rc.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string insertQuery = "INSERT INTO mcuov.medical_certificate(RegNum,Subject_Name,Course_Code,Lecturer_Incharge,Medical_Issue) VALUES('" + txtRegNum.Text + "','" + txtSub.Text + "','" + txtCoCode.Text + "','" + txtLecIn.Text + "','" + txtMedIssue.Text + "')";
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(insertQuery, conn);

            try
            {
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Data Inserted!");
                }
                else
                {
                    MessageBox.Show("Data not Inserted");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            conn.Close();

            txtCoCode.Text = "";
            txtLecIn.Text = "";
            txtMedIssue.Text = "";
            txtRegNum.Text = "";
            txtSub.Text = "";
        }
    }
}
