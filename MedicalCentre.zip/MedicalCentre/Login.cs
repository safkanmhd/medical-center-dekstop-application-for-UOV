﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicalCentre
{
    public partial class Login : Form
    {
        public Login()
        {
            Thread t = new Thread(new ThreadStart(LoadingForm));
            t.Start();
            Thread.Sleep(5000);
            InitializeComponent();
            t.Abort();
        }

        public void LoadingForm()
        {
            Application.Run(new LoadingScreen());
        }

        private void userName_DoubleClick(object sender, EventArgs e)
        {

        }

        private void Loggin_Click(object sender, EventArgs e)
        {
            if (userName.Text == "doc123" && userPass.Text == "doc123")
            {
                DoctorHome doc = new DoctorHome();
                MessageBox.Show("Login Sucsess", "Welcome Doc!");
                doc.Show();
                this.Hide();

            }

            else if (userName.Text == "pharma123" && userPass.Text == "pharma123")
            {
                PharmacistHome phar = new PharmacistHome();
                MessageBox.Show("Login Success", "Welcome");
                phar.Show();
                this.Hide();
            }


            else if (userName.Text == "rec123" && userPass.Text == "rec123")
            {
                ReceptionistSelection rec = new ReceptionistSelection();
                MessageBox.Show("Login Success", "Welcome");
                rec.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Your user name and password is incorrrect", "Error");

            }

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Details dt=new Details();
            dt.Show();
        }
    }
}
